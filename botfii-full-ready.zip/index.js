// Entry point bot file
console.log('Bot started');